MINDtest <-
function(xytable, index, R){

   dat=as.matrix(xytable)
   I=nrow(dat)
   J=ncol(dat)

   xmargin=as.matrix(rowSums(dat))
   ymargin=as.matrix(colSums(dat))

   xdat=numeric()
   ydat=numeric()

   for(i in 1:I){
   if(xmargin[i,1]>0){
   xdat=c(xdat,rep(i,xmargin[i,1]))
   }
   }

   for(j in 1:J){
   if(ymargin[j,1]>0){
   ydat=c(ydat,rep(j,ymargin[j,1]))
   }
   }

   dat0=xmargin%*%t(ymargin)/sum(dat)
   dat0=as.matrix(dat0)

   if(index=="max"){
   
   MINDxy_obs=max(abs(dat-dat0)) 

   MINDxy_perm=numeric(R)

   for(i in 1:R){

     ydat_perm=sample(ydat)     
     dat_perm=as.matrix(table(xdat,ydat_perm))
     MINDxy_perm[i]=max(abs(dat_perm-dat0))
     
   }

   }

   else if(index!="max"){
 
   index=as.numeric(index)
   
   MINDxy_obs=sum((abs(dat-dat0))^index)^(1/index)
    
   MINDxy_perm=numeric(R)

   for(i in 1:R){

     ydat_perm=sample(ydat)     
     dat_perm=as.matrix(table(xdat,ydat_perm))
     MINDxy_perm[i]=sum((abs(dat_perm-dat0))^index)^(1/index)
     
   }

   }

   p.value=sum(MINDxy_perm>MINDxy_obs)/R

   return(p.value)

}
