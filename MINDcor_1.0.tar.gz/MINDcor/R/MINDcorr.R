MINDcorr <-
function(xytable, index){

   dat=as.matrix(xytable)
   I=nrow(dat)
   J=ncol(dat)
   phat=dat/sum(dat)

   xmargin=as.matrix(rowSums(phat))
   ymargin=as.matrix(colSums(phat))

   phat0=xmargin%*%t(ymargin)
   phat0=as.matrix(phat0)

   if(index=="max"){
   
   MINDxy=max(abs(phat-phat0))

   MINDx=max(xmargin-xmargin^2)
   MINDy=max(ymargin-ymargin^2)

   COR=MINDxy/(sqrt(MINDx)*sqrt(MINDy)) 

   }

   else if(index!="max"){
 
   index=as.numeric(index)
   
   MINDxy=sum((abs(phat-phat0))^index)^(1/index)
 
   MINDx1=sum((xmargin-xmargin^2)^index)
   MINDx2=sum((xmargin%*%t(xmargin))^index)-sum(xmargin^(2*index))

   MINDx=(MINDx1+MINDx2)^(1/index)
 

   MINDy1=sum((ymargin-ymargin^2)^index)
   MINDy2=sum((ymargin%*%t(ymargin))^index)-sum(ymargin^(2*index))

   MINDy=(MINDy1+MINDy2)^(1/index)
   
   COR=MINDxy/(sqrt(MINDx)*sqrt(MINDy))

   }

   return(COR)
}
